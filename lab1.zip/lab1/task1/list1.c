#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define KEYSIZE 16

void main(){
	FILE * fp;
	fp = fopen("randomnum.txt", "w");
	if(fp == NULL){
        printf("Create file fail.\n");
        exit(0);
    	}
	
	int i;
	int d;
	unsigned long second = 1524020929;
	char key[KEYSIZE];
	
	for (unsigned long d=second; d > second-(2*60*60); d-- ){	
		srand (d);
		for (i = 0;i<KEYSIZE;i++){
			key[i] = rand()%256;
			fprintf(fp,"%.2x", (unsigned char)key[i]);
		}
		fprintf(fp,"\n");	
	}
	fclose(fp);
}
