# Plaintext:  255044462d312e350a25d0d4c5d80a34
# Ciphertext: d06bf9d0dab8e8ef880660d2af65aa82
# IV:         09080706050403020100A2B2C2D2E2F2
# date -d "2018-04-17 23:08:49" +%s
# 1524020929

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

plaintext = bytearray.fromhex("255044462d312e350a25d0d4c5d80a34")
iv = bytearray.fromhex("09080706050403020100A2B2C2D2E2F2")
ciphertext = bytearray.fromhex("d06bf9d0dab8e8ef880660d2af65aa82")
f = open("../task1/randomnum.txt", "r")
rn = f.readlines()

for key in rn:
    key = key.strip("/n")
    keyb = bytearray.fromhex(key)
    cipher = AES.new(keyb, AES.MODE_CBC, iv)
    ct_bytes = cipher.encrypt(plaintext)
    if ct_bytes == ciphertext:
        print("key is ", key)
        exit(1)

